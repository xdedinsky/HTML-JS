var canvas = document.getElementById('gameCanvas');
var ctx = canvas.getContext('2d');
var scoreEl = document.getElementById('scoreSum');
var levelEl = document.getElementById('level'); 
var scoreGettedEl = document.getElementById('scoreGetted'); 
var isPaused = true;
var pauseButton = document.getElementById('pauseButton');
var inGameModalElement = document.getElementById('inGameModal');
const audio = new Audio('winSound.mp3');

function pauseGame() {
    isPaused = true;
}

function continueGame() {
    if (isPaused) {
        isPaused = false;
        gameLoop();
    }
}
window.onresize = function(){ location.reload(); }
var pauseImage = document.getElementById('pauseImage');

function toggleGame() {
    if (isPaused) {
        pauseImage.src = 'images/pause.png';
        continueGame();
    } else {
        pauseImage.src = 'images/play.png';
        pauseGame();
    }
}

var player = {
    x: canvas.width / 2,
    y: canvas.height - 30,
    width: 50,
    height: 50,
    speed: 5,
    dx: 0,
    dy: 0, 
    jumping: false,
    originalHeight: 50, 
    halfHeight: 25, 
    slowSpeed: 2.5 
};

var keysPressed = {
    a: false,
    d: false,
    s: false,
    w: false
};

var levels;
var objects = [];
var objectWidth = 30;
var objectHeight = 30;
var objectSpeed;
var score = 0;
var level = 1;
var gameOver = false;

function addObject() {
    
    if(!isPaused && !document.hidden && !gameOver){
        objects.push({
            x: Math.random() * (canvas.width - objectWidth),
            y: -objectHeight,
            width: objectWidth,
            height: objectHeight
        });
    }
}

 

function updateObjects() {
    for (var i = 0; i < objects.length; i++) {
        if (objects[i].type === 'right') {
            objects[i].x -= objectSpeed;
            if (objects[i].x + objects[i].width < 0) {
                objects.splice(i, 1);
            }
        } else {
            objects[i].y += objectSpeed;
            if (objects[i].y > canvas.height) {
                objects.splice(i, 1);
                score += 10;
                updateScoreAndLevelDisplay();
                if (score >= levels[level - 1].maxScore) {
                    cancelAnimationFrame(requestId);
                    audio.play();
                    if (level < levels.length) {
                        showNextLevelButton();
                    } else {
                        gameOver = true;
                        showRestartButton();
                        ctx.clearRect(0, 0, canvas.width, canvas.height);
                        ctx.fillStyle = 'black';
                        ctx.font = '48px serif';
                        var winText = document.createElement('h2');
                        winText.innerHTML = 'Vyhral si';
                        winText.style.textAlign = 'center';
                        winText.style.color = 'rgb(9, 38, 53)';
                        score = 0;
                        objects=[];
                    
                        inGameModalElement.appendChild(winText);

                        let totalScore = 0
                        for(let i = 0; i < levels.length; i++) {
                            totalScore += levels[i].maxScore;
                        }

                        var winDescriptionText = document.createElement('p');
                        winDescriptionText.style.textAlign = 'center';
                        winDescriptionText.innerHTML = 'Celkové skóre ' + totalScore;
                        
                        inGameModalElement.appendChild(winDescriptionText);

                        saveProgress();
                    }
                    return;
                }
            }
        }
    }
}

function updateScoreAndLevelDisplay() {
    if (levels){
        var totalScore = levels[level - 1].maxScore;
    }
    scoreEl.textContent = "Skóre: " + score + " / " + totalScore;
    levelEl.textContent = "Úroveň: " + level;
}

function saveProgress() {
    if (score === levels[level-1].maxScore) {
        score = 0;
        level = level+1;
        if (level > levels.length) {
            level = 1;
        }
        objects = [];
    }
    localStorage.setItem('level', level);
    localStorage.setItem('scoreSum', score);
    localStorage.setItem('playerX', player.x);
    localStorage.setItem('playerY', player.y);
    localStorage.setItem('objects', JSON.stringify(objects));
    updateScoreAndLevelDisplay(); 
}

function loadProgress() {
    var savedLevel = localStorage.getItem('level');
    var savedScoreSum = localStorage.getItem('scoreSum');
    var savedPlayerX = localStorage.getItem('playerX');
    var savedPlayerY = localStorage.getItem('playerY');
    var savedObjects = localStorage.getItem('objects');

    if (savedLevel) {
        level = parseInt(savedLevel);
    }
    if (savedScoreSum) {
        score = parseInt(savedScoreSum);
    }
    if (savedPlayerX) {
        player.x = parseFloat(savedPlayerX);
    }
    if (savedPlayerY) {
        player.y = parseFloat(savedPlayerY);
    }
    if (savedObjects) {
        objects = JSON.parse(savedObjects);
    }
    updateScoreAndLevelDisplay(); // Update the display with the loaded progress
}

var gameElement = document.getElementById('game');

function showNextLevelButton() {
    pauseButton.style.display = 'none';
    var nextLevelButton = document.createElement('button');
    nextLevelButton.textContent = 'Ďalší Level';
    nextLevelButton.id = 'nextLevelButton';
    nextLevelButton.className = 'startButton';

    var descriptionText = document.createElement('p');
    descriptionText.style.textAlign = 'center';
    if(level < levels.length) {
        descriptionText.textContent = levels[level].description;
    }

    nextLevelButton.onclick = function() {
        pauseButton.style.display = 'block';
        inGameModalElement.removeChild(descriptionText);
        inGameModalElement.removeChild(nextLevelButton);
        levelUp();
        resetGame();
        gameLoop();
    };
    inGameModalElement.appendChild(descriptionText);
    inGameModalElement.appendChild(nextLevelButton);
    inGameModalElement.style.display = 'flex';
}

function levelUp() {
    if (level < levels.length) {
        level++;
        objectSpeed = levels[level - 1].speed;
        score = 0;
        objects = [];
    } else {
        gameOver = true;
        saveProgress();
        showRestartButton();
        score = 0;
        objects = [];
    }
}

function resetGame() {
    if(level === 0) {
        level++;
    }
    objectSpeed = levels[level - 1].speed; // Nastaví rýchlosť objektov na rýchlosť aktuálnej úrovne
    player.height = player.originalHeight;
    player.speed = 5;
    updateScoreAndLevelDisplay();
}

function checkForCollisions() {
    for (var i = 0; i < objects.length; i++) {
        if (player.x < objects[i].x + objects[i].width &&
            player.x + player.width > objects[i].x &&
            player.y < objects[i].y + objects[i].height &&
            player.y + player.height > objects[i].y) {
            if (objects[i].type === 'right' && level >= 5 && player.isShrunk) {
                continue;
            }
            gameOver = true;
            showRestartButton();
        }
    }
}

function showRestartButton() {
    var restartButton = document.getElementById('restartButton');
    inGameModalElement.style.display = 'flex';
    pauseButton.style.display = 'none';
    restartButton.style.display = 'block';
}

function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = 'blue';
    ctx.fillRect(player.x, player.y, player.width, player.height);
    ctx.fillStyle = 'red';
    for (var i = 0; i < objects.length; i++) {
        ctx.fillRect(objects[i].x, objects[i].y, objects[i].width, objects[i].height);
    }
    updateObjects();
    checkForCollisions();
}

function updatePlayer() {
    player.x += player.dx;
    player.y += player.dy;
    if (keysPressed.a) {
        player.dx = -player.speed;
    }
    if (keysPressed.d) {
        player.dx = player.speed;
    }
    if (player.x < 0) player.x = 0;
    if (player.x + player.width > canvas.width) player.x = canvas.width - player.width;
    if (player.y < canvas.height - player.originalHeight) {
        player.dy += 0.5; // gravitácia
    } else {
        player.y = canvas.height - player.height;
        player.dy = 0;
        player.jumping = false;
    }
    if (keysPressed.s) {
        player.isShrunk = true;
        player.height = player.halfHeight;
        player.speed = player.slowSpeed;
    }
}

function updatePlayerSpeed() {
    if (keysPressed.s) {
        player.speed = player.slowSpeed;
    } else {
        player.speed = 5; // alebo akúkoľvek štandardnú rýchlosť máte
    }
}

var buttonSlow = document.getElementById('buttonSlow');

// Event listener pre dotyk tlačidla (spomalenie a zmenšenie)
buttonSlow.addEventListener('touchstart', function(e) {
    e.preventDefault(); // Zabráni štandardnej reakcii prehliadača na dotyk
    player.height = player.halfHeight;
    player.speed = player.slowSpeed;
    
});

// Event listener pre ukončenie dotyku tlačidla (vrátenie do pôvodného stavu)
buttonSlow.addEventListener('touchend', function(e) {
    e.preventDefault(); // Zabráni štandardnej reakcii prehliadača na ukončenie dotyku
    player.height = player.originalHeight;
    player.speed = 5;
    
});

function addRightObject() {
    var randomY;

    if (Math.random() < 0.5) {
        // Prvá možnosť
        randomY = canvas.height - player.originalHeight - 10;
    } else {
        // Druhá možnosť
        randomY = canvas.height - objectHeight;
    }

    if (level === 3) {
        objects.push({
            x: canvas.width,
            // y: Math.random() * (canvas.height - objectHeight),
            y: canvas.height - player.originalHeight - 10,
            width: objectWidth,
            height: objectHeight,
            type: 'right'
        });
    } else if (level === 4) {

        objects.push({
            x: canvas.width,
            // y: Math.random() * (canvas.height - objectHeight),
            y: canvas.height - objectHeight,
            width: objectWidth,
            height: objectHeight,
            type: 'right'
        });
    } else if (level >= 5){
        objects.push({
            x: canvas.width,
            // y: Math.random() * (canvas.height - objectHeight),
            y: randomY,
            width: objectWidth,
            height: objectHeight,
            type: 'right'
        });
    }
}

document.addEventListener('keydown', function(e) {
    if (e.key === 'a' || e.key === 'A') {
        keysPressed.a = true;
        player.dx = -player.speed;
    } else if (e.key === 'd' || e.key === 'D') {
        keysPressed.d = true;
        player.dx = player.speed;
    } else if (e.key === 's' || e.key === 'S') {
        keysPressed.s = true;
        player.isShrunk = true;
        player.height = player.halfHeight; 
        player.speed = player.slowSpeed; 
        updatePlayerSpeed();
    } else if (e.key === 'w' || e.key === 'W') {
        keysPressed.w = true;
        if (!player.jumping) {
            player.dy = -10;
            player.jumping = true;
        }
    }
});

var buttonJump = document.getElementById('buttonJump');
buttonJump.addEventListener('touchstart', function(e) {
    e.preventDefault();
    if (!player.jumping) {
        player.dy = -10;
        player.jumping = true;
    }
});

buttonJump.addEventListener('touchend', function(e) {
    e.preventDefault();
});




document.addEventListener('keyup', function(e) {
    if (e.key === 'a' || e.key === 'A' || e.key === 'd' || e.key === 'D') {
        player.dx = 0;
    } else if ((e.key === 's' || e.key === 'S')) {
        keysPressed.s = false;
        player.isShrunk = false;
        player.height = player.originalHeight;
        player.speed = 5;
    }
});

document.addEventListener('keyup', function(e) {
    if (e.key === 'a' || e.key === 'A') {
        keysPressed.a = false;
    } else if (e.key === 'd' || e.key === 'D') {
        keysPressed.d = false;
    } else if (e.key === 's' || e.key === 'S') {
        keysPressed.s = false;
        player.isShrunk = false;
        player.height = player.originalHeight;
        updatePlayerSpeed();
    } else if (e.key === 'w' || e.key === 'W') {
        keysPressed.w = false;
    }

    if (!keysPressed.a && !keysPressed.d) {
        player.dx = 0;
    }
});


window.addEventListener('deviceorientation', function(e) {
    var tilt = e.gamma;
    player.dx = tilt * player.speed * 2.5 / 90;
});

var requestId;
function gameLoop() {
    if (!gameOver && !isPaused) {
        requestId = requestAnimationFrame(gameLoop);
        draw();
        updatePlayer();
    }
}

function restartGame() {
    inGameModalElement.innerHTML = '<button id="restartButton" class="startButton">Reštart</button>';

    var restartButton = document.getElementById('restartButton');
    restartButton.addEventListener('click', function() {
        if (score === levels[levels.length - 1].maxScore) {
            score = 0;
        }
        saveProgress();
        restartGame();
    });
    if (level == 5 && score == levels[levels.length - 1].maxScore){
        level = 1;
    }
    score = 0;
    objects = [];
    document.getElementById('restartButton').style.display = 'none';
    pauseButton.style.display = 'flex';
    gameOver = false;

    resetGame();
    requestAnimationFrame(gameLoop);
}

function loadLevels() {
    fetch('./script/levels.json')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            levels = data.levels;
            resetGame();
            gameLoop();
        })
        .catch(error => {
            console.error('Chyba pri načítaní úrovní:', error);
        });
}
window.addEventListener('beforeunload', saveProgress);
var restartButton = document.getElementById('restartButton');
restartButton.addEventListener('click', function() {
    if (score === levels[levels.length - 1].maxScore) {
        score = 0;
    }
    saveProgress();
    restartGame();
});

function isTouchDevice() {
    return 'ontouchstart' in window || navigator.maxTouchPoints > 0 || navigator.msMaxTouchPoints > 0;
}

loadProgress();
loadLevels();

pauseButton.addEventListener('click', function() {
    var startButton = document.getElementById('startButton');
    if (startButton) {
        startButton.style.display = 'none';
    }
    toggleGame();
});

var interval1 = 900; // Pôvodný interval pre padajúce kocky
var interval2 = 4000; // Nový interval pre kocky prichádzajúce zprava

// Kontrola, či je dotykové zariadenie
if (isTouchDevice()) {
    // Zdvojnásobenie intervalov, ak nie je dotykové zariadenie
    interval1 *= 1.5;
    interval2 *= 1.5;
}

setInterval(addObject, interval1); // Pôvodný interval pre padajúce kocky
setInterval(addRightObject, interval2); // Nový interval pre kocky prichádzajúce zprava