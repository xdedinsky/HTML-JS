var modalElement = document.getElementById('modal');
var gameElement = document.getElementById('game');
var startGameButton = document.getElementById('startGameButton');
var gameCanvas = document.getElementById('gameCanvas');
var pauseButton = document.getElementById('pauseButton');
var underCanvas = document.getElementById('underCanvas');
var gameControlDiv = document.getElementById('gameControl');
var inGameModalElement = document.getElementById('inGameModal');
var wholeGameRestart = document.getElementById('wholeGameRestartButton');
var infoButton = document.getElementById('infoButton');

var pageWigth = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
var pageHeight = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;

function mobileConfigModal() {
    gameControlDiv.innerHTML = `
        <h3>Ovládanie hry:</h3>
        <div class="keyboard">
            <img src="images/right.png" alt="">
            <p>Posunutie doprava</p>
        </div>
        <div class="keyboard">
            <img src="images/left.png" alt="">
            <p>Posunutie doľava</p>
        </div>
        <div class="keyboard">
            <img src="images/up_arrow.png" alt="">
            <p>Výskok</p>
        </div>
        <div class="keyboard">
            <img src="images/down_arrow.png" alt="">
            <p>Prikrčenie</p>
        </div>
    `;
}

function setGameOnStart() {
    if(isTouchDevice()) {
        gameCanvas.style.width = (pageWigth * 0.95) + 'px';
        gameCanvas.style.height = (pageHeight * 0.35) + 'px';
        underCanvas.style.width = (pageWigth * 0.95) + 'px';
        inGameModalElement.style.width = (pageWigth * 0.8) + 'px';
        buttonJump.style.display = 'block';
        buttonSlow.style.display = 'block';
        mobileConfigModal();
    } else {
        gameCanvas.style.width = (pageWigth * 0.5) + 'px';
        gameCanvas.style.height = (pageHeight * 0.6) + 'px';
        underCanvas.style.width = (pageWigth * 0.5) + 'px';
        inGameModalElement.style.width = (pageWigth * 0.45) + 'px';
        buttonJump.style.display = 'none';
        buttonSlow.style.display = 'none';
    }
}

let counter = 0;

document.addEventListener('DOMContentLoaded', function () {
    setGameOnStart();

    startGameButton.addEventListener("click", function() {
        modalElement.style.display = 'none';
        gameElement.style.display = 'flex';

        var startButton = document.createElement('button');
        startButton.id = 'startButton';
        startButton.className = 'startButton';
        startButton.textContent = 'Začať hru';

        var descriptionText = document.createElement('p');
        descriptionText.style.textAlign = 'center';
        descriptionText.textContent = levels[level-1].description;

        if(counter === 0) {
            counter++;
            inGameModalElement.appendChild(descriptionText);
            inGameModalElement.appendChild(startButton);
        }

        startButton.addEventListener('click', function() {
            inGameModalElement.style.display = 'none';
            inGameModalElement.removeChild(startButton);
            inGameModalElement.removeChild(descriptionText);
            pauseButton.style.display = 'block';
            continueGame();
        });
      });

    wholeGameRestart.addEventListener("click", function() {
        inGameModalElement.innerHTML = '<button id="restartButton" class="startButton">Reštart</button>';

        var restartButton = document.getElementById('restartButton');
        restartButton.addEventListener('click', function() {
            if (score === levels[levels.length - 1].maxScore) {
                score = 0;
            }
            saveProgress();
            restartGame();
        });

        pauseGame();
        resetGame();

        var startButton = document.createElement('button');
        startButton.id = 'startButton';
        startButton.className = 'startButton';
        startButton.textContent = 'Začať hru odznova';
        pauseImage.src = 'images/play.png';
        startButton.addEventListener('click', function() {
            pauseImage.src = 'images/pause.png';
            inGameModalElement.style.display = 'none';
            inGameModalElement.removeChild(startButton);
            pauseButton.style.display = 'block';
            level = 1;
            score = 0;
            objects = [];
            location.reload();
            updateScoreAndLevelDisplay();
            continueGame();
        });

        inGameModalElement.appendChild(startButton);
        inGameModalElement.style.display = 'flex';
    });

    infoButton.addEventListener("click", function() {
        modalElement.style.display = 'flex';
        gameElement.style.display = 'none';

        startGameButton.addEventListener("click", function() {
            modalElement.style.display = 'none';
            gameElement.style.display = 'flex';
        });
    });
});