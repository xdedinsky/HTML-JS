var inputGlobal;
class AmplitudaSlider extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this.render();
  }

  static get observedAttributes() {
    return ['width', 'min', 'max'];
  }

  attributeChangedCallback( oldValue, newValue) {
    if (oldValue !== newValue) {
      this.render();
    }
  }

  render() {
    const width = this.getAttribute('width') || '100%';
    const min = parseInt(this.getAttribute('min')) || 1;
    const max = parseInt(this.getAttribute('max')) || 10;
    const initialValue = min;
    //set width of input to same as slider
  
    this.shadowRoot.innerHTML = `
      <div class="slidecontainer" style="width: ${width}; position: relative;">
        <button class="slider-button" id="sliderButton">${initialValue}</button>
        <input type="range" min="${min}" max="${max}" value="${initialValue}" step="1" class="slider" id="myRange">
      </div>
      <div class="slidecontainer" style="width: ${width} ; position: relative;">
        <input class="inputNumber" type="number" id="myNumber" style="width: ${width}; value="${initialValue}" />
      </div>
        <style>
          .slidecontainer {
            width: 100%;            
          }

          .slider, .inputnumber {
            -webkit-appearance: none;
            width: 100%;
            height: 10px;
            background: #fff;
            border: 2px solid #515051;
            border-radius: 4px;
            outline: none;
            position: relative;
            z-index: 1;
          }

          .slider::-webkit-slider-thumb {
            display: none;
          }

          .slider-button {
            font-size: 15px;
            -webkit-appearance: none;
            appearance: none;
            width: 45px;
            height: 25px;
            background: #efefef;
            border: 2px solid #515051;
            border-radius: 6px;
            cursor: pointer;
            position: absolute;
            top: -1px;
            left: 0;
            text-align: center;
            z-index: 2;
          }
        </style>
      </div>
    `;
    inputGlobal = this.shadowRoot.querySelector("#myNumber");
    const sliderButton = this.shadowRoot.querySelector('.slider-button');
    const slider = this.shadowRoot.querySelector('.slider');
    const inputNumber = this.shadowRoot.querySelector('.inputNumber');
    inputNumber.value = initialValue;
    sliderButton.addEventListener('mousedown', (event) => {
      event.preventDefault();
      const startX = event.clientX;
      const startLeft = parseFloat(getComputedStyle(sliderButton).left);

      const mouseMoveHandler = (event) => {
        const diffX = event.clientX - startX;
        const newLeft = startLeft + diffX;
        const minLeft = 0;
        const maxLeft = slider.offsetWidth - sliderButton.offsetWidth;

        if (newLeft >= minLeft && newLeft <= maxLeft) {
          sliderButton.style.left = `${newLeft}px`;
          const percentage = newLeft / maxLeft;
          const value = Math.round(min + percentage * (max - min));
          slider.value = value;
          sliderButton.textContent = value;
        }
      };

      const mouseUpHandler = () => {
        document.removeEventListener('mousemove', mouseMoveHandler);
        document.removeEventListener('mouseup', mouseUpHandler);
        multiplyData();
      };

      document.addEventListener('mousemove', mouseMoveHandler);
      document.addEventListener('mouseup', mouseUpHandler);
      drawGraphs();
    });

    sliderButton.addEventListener('mouseup', (event) => {
      event.preventDefault();
      this.updateInputs();
      drawGraphs();
    });
  }

  /*listener for input*/
  connectedCallback() {
    var inputNumber = this.shadowRoot.querySelector("#myNumber");
    var sliderButton = this.shadowRoot.querySelector('.slider-button');
    var slider = this.shadowRoot.querySelector('.slider');

    inputNumber.addEventListener('change', function() {
      var value = parseInt(this.value);
      if (value >= parseInt(slider.min) && value <= parseInt(slider.max)) {
        slider.value = value;
        sliderButton.textContent = value;
        inputNumber.value = value;
        inputNumber.textContent = value;
        multiplyData();
        multiplyData();
      }
    });
    inputNumber.addEventListener('input', function() {
      var value = parseInt(this.value);
      var minValue = parseInt(slider.min);
      var maxValue = parseInt(slider.max);
  
      if (value >= minValue && value <= maxValue) {
          slider.value = value;
          sliderButton.textContent = value;
          inputNumber.value = value;
          inputNumber.textContent = value;
          var percentage = (value - minValue) / (maxValue - minValue);
          var sliderWidth = slider.offsetWidth - sliderButton.offsetWidth;
          var newLeft = Math.round(percentage * sliderWidth);
          sliderButton.style.left = `${newLeft}px`;
          multiplyData();
      } else {
          // Reset to the minimum value
          slider.value = minValue;
          sliderButton.textContent = minValue;
          inputNumber.value = minValue;
          inputNumber.textContent = minValue;
          sliderButton.style.left = '0px';
          multiplyData();
      }
  });
  }

  updateInputs() {
    var inputNumber = this.shadowRoot.querySelector("#myNumber");
    var sliderButton = this.shadowRoot.querySelector('.slider-button');

    // Získajte hodnotu zo slideru
    var sliderValue = parseInt(sliderButton.textContent);

    // Nastavte hodnotu inputu
    inputNumber.value = sliderValue;
  }
}

customElements.define('amplituda-slider', AmplitudaSlider);

var arrGraphX = [0];
var arrGraphY1 = [0];
var arrGraphY2 = [1];

var arrGraphX_def = [];
var arrGraphY1_def = [];
var arrGraphY2_def = [];

var trace1, trace2, data1, data2, source;

var updateData = true;
var displayGraph1 = true;
var displayGraph2 = true;  

if(typeof(EventSource) !== "undefined") 
{
  source = new EventSource("https://old.iolab.sk/evaluation/sse/sse.php");  
}
else 
{
  document.getElementById("fetchedData").innerHTML = "Your browser does not support server events!";
}

function fetchData(){  
  source.addEventListener("message", function(e)
  {
    dataGetter(e);    
	}); 
}

function toogleSin(){
  if(displayGraph1 == true){
    displayGraph1 = false;
  } else{
    displayGraph1 = true;
  } 
  
  drawGraphs();
}

function toogleCos(){
  if(displayGraph2 == true){
    displayGraph2 = false;
  } else{
    displayGraph2 = true;
  } 
  drawGraphs();
}

function killer(){
  updateData = false;
}

function multiplyData(){
  arrGraphY1 = [];
  arrGraphY2 = [];
  for (var i = 0; i < arrGraphY1_def.length; i++) {
    arrGraphY1.push(arrGraphY1_def[i] * inputGlobal.value);
    arrGraphY2.push(arrGraphY2_def[i] * inputGlobal.value);
  }
  arrGraphX_def; 
  
  drawGraphs();
}

function dataGetter(e){
  var data = JSON.parse(e.data);
  if(updateData == true){
    if(+data.x == 0){
      arrGraphY1[0] = data.y1;
      arrGraphY2[0] = data.y2;
      arrGraphY1_def = arrGraphY1;
      arrGraphY2_def = arrGraphY2;    
  } else{
      arrGraphX_def.push(data.x);
      arrGraphY1_def.push(data.y1);
      arrGraphY2_def.push(data.y2);
  }
    multiplyData(); 
  }  
}

window.addEventListener('resize', drawGraphs);



function drawGraphs(){
  trace1 = {
    x: arrGraphX_def,
    y: arrGraphY1,
    type: 'scatter',
    name: 'Sin',
    line: {
      color: 'cyan',
      width: 2
    }
  };
  
  trace2 = {
    x: arrGraphX_def,
    y: arrGraphY2,
    type: 'scatter',
    name: 'Cos',
    line: {
      color: 'magenta',
      width: 2
    }
  };

  data1 = [trace1];
  data2 = [trace2];
  //use this layout for mobile, so make an if statement
  if (window.innerWidth < 768) {
    var layout = {
      title: 'Zašumený sínus a kosínus',
      showlegend: true,
      font: {
        color: '#fff'
      },
      xaxis: 
          {
            title: 'os X',
          },
      yaxis:
          {
            title: 'os Y',
          },
      paper_bgcolor: "#414141",
      plot_bgcolor: "#292929",
      width: 350,
    };
  } else {
    var layout = {
      title: 'Zašumený sínus a kosínus',
      showlegend: true,
      font: 
      {
        color: '#fff'
      },
      xaxis: 
          {
            title: 'os X',
          },
      yaxis:
          {
            title: 'os Y',
          },
      width: 600,
      paper_bgcolor: "#414141",
      plot_bgcolor: "#292929",
    };
  }
  
  var config = { responsive: true ,};

  Plotly.newPlot(graph, [], layout, config);     
  
  if(displayGraph1 == true && displayGraph2 == true){
    Plotly.addTraces(graph, data1);
    Plotly.addTraces(graph, data2);
  }
  else if(displayGraph1 == true && displayGraph2 == false){
    Plotly.addTraces(graph, data1); 
  }
  else if(displayGraph1 == false && displayGraph2 == true){
    Plotly.addTraces(graph, data2);  
  }  
}

