async function fetchData() {
  try {
    const response = await fetch('z03.xml');
    const data = await response.text();
    parseXml(data);
    const orientation = window.innerWidth > window.innerHeight ? 'landscape' : 'portrait';
    orientation === 'landscape' ? paintBar(zaznamyAll) : paintBarMobile(zaznamyAll);
    paintPie(zaznamyAll, 'ZS 2021/2022');
    paintPie(zaznamyAll, 'ZS 2020/2021');
    paintPie(zaznamyAll, 'ZS 2019/2020');
    paintPie(zaznamyAll, 'ZS 2018/2019');
    paintPie(zaznamyAll, 'ZS 2017/2018');
    paintPie(zaznamyAll, 'ZS 2016/2017');
    paintCustomGraph(zaznamyAll);
  } catch (error) {
    console.error('Chyba pri načítaní XML:', error);
  }
}

window.addEventListener('resize', () => {
  const orientation = window.innerWidth > window.innerHeight ? 'landscape' : 'portrait';
  orientation === 'landscape' ? paintBar(zaznamyAll) : paintBarMobile(zaznamyAll);
  paintCustomGraph(zaznamyAll);
  paintPie(zaznamyAll, 'ZS 2021/2022');
  paintPie(zaznamyAll, 'ZS 2020/2021');
  paintPie(zaznamyAll, 'ZS 2019/2020');
  paintPie(zaznamyAll, 'ZS 2018/2019');
  paintPie(zaznamyAll, 'ZS 2017/2018');
  paintPie(zaznamyAll, 'ZS 2016/2017');
});

window.addEventListener('load', () => {
  const orientation = window.innerWidth > window.innerHeight ? 'landscape' : 'portrait';
  orientation === 'landscape' ? paintBar(zaznamyAll) : paintBarMobile(zaznamyAll);
  paintCustomGraph(zaznamyAll);
  paintPie(zaznamyAll, 'ZS 2021/2022');
  paintPie(zaznamyAll, 'ZS 2020/2021');
  paintPie(zaznamyAll, 'ZS 2019/2020');
  paintPie(zaznamyAll, 'ZS 2018/2019');
  paintPie(zaznamyAll, 'ZS 2017/2018');
  paintPie(zaznamyAll, 'ZS 2016/2017');
});



const zaznamyAll = [];
function parseXml(xmlData) {
  const parser = new DOMParser();
  const xmlDocument = parser.parseFromString(xmlData, 'text/xml');
  const zaznamy = xmlDocument.querySelectorAll('zaznam');

  for (const zaznam of zaznamy) {
    const rok = zaznam.querySelector('rok').textContent;
    const hodnotenie = zaznam.querySelector('hodnotenie');
    const A = hodnotenie.querySelector('A').textContent;
    const B = hodnotenie.querySelector('B').textContent;
    const C = hodnotenie.querySelector('C').textContent;
    const D = hodnotenie.querySelector('D').textContent;
    const E = hodnotenie.querySelector('E').textContent;
    const FX = hodnotenie.querySelector('FX').textContent;
    const FN = hodnotenie.querySelector('FN').textContent;
    zaznamyAll.push({rok, A, B, C, D, E, FX, FN});
  }
}

function paintBar(zaznamyAll) {
  var arrayX = [];
  for (const zaznam of zaznamyAll) {
    arrayX.push(zaznam.rok);
  }
  
  var arrayYa = [];
  for (const zaznam of zaznamyAll) {
    arrayYa.push(zaznam.A);
  }

  var arrayYb = [];
  for (const zaznam of zaznamyAll) {
    arrayYb.push(zaznam.B);
  }

  var arrayYc = [];
  for (const zaznam of zaznamyAll) {
    arrayYc.push(zaznam.C);
  }

  var arrayYd = [];
  for (const zaznam of zaznamyAll) {
    arrayYd.push(zaznam.D);
  }

  var arrayYe = [];
  for (const zaznam of zaznamyAll) {
    arrayYe.push(zaznam.E);
  }

  var arrayYfx = [];
  for (const zaznam of zaznamyAll) {
    arrayYfx.push(zaznam.FX);
  }

  var arrayYfn = [];
  for (const zaznam of zaznamyAll) {
    arrayYfn.push(zaznam.FN);
  }

  var trace1 = {
    x: arrayX,
    y: arrayYa,
    name: 'A',
    type: 'bar',
    orientation: 'v',
  };

  var trace2 = {
      x: arrayX,
      y: arrayYb,
      name: 'B',
      type: 'bar',
      orientation: 'v',
  };

  var trace3 = {
      x: arrayX,
      y: arrayYc,
      name: 'C',
      type: 'bar',
      orientation: 'v',
  };

  var trace4 = {
      x: arrayX,
      y: arrayYd,
      name: 'D',
      type: 'bar',
      orientation: 'v',
  };

  var trace5 = {
      x: arrayX,
      y: arrayYe,
      name: 'E',
      type: 'bar',
      orientation: 'v',
  };

  var trace6 = {
      x: arrayX,
      y: arrayYfx,
      name: 'FX',
      type: 'bar',
      orientation: 'v',
  };

  var trace6 = {
    x: arrayX,
    y: arrayYfn,
    name: 'FN',
    type: 'bar',
    orientation: 'v',
  };

  var dataPlotBar = [trace1, trace2, trace3, trace4, trace5, trace6];

  var layout = { 
    barmode: 'group' , 
    title: 'Barový graf známok študentov', 
    font: {
      color: '#fff'
    },
    xaxis: 
        {
          title: 'Akademický rok',
          tickangle: -20,
        },
    yaxis:
        {
          title: 'Počet študentov',
        },
    width: 600,
    paper_bgcolor: "rgba(0,0,0,0)",
    plot_bgcolor: "rgba(0,0,0,0)",
  };

  var config = { responsive: true ,};

  Plotly.newPlot('graphBar', dataPlotBar, layout, config);
  
}

function paintBarMobile(zaznamyAll) {
  var arrayX = [];
  for (const zaznam of zaznamyAll) {
    arrayX.push(zaznam.rok);
  }
  
  var arrayYa = [];
  for (const zaznam of zaznamyAll) {
    arrayYa.push(zaznam.A);
  }

  var arrayYb = [];
  for (const zaznam of zaznamyAll) {
    arrayYb.push(zaznam.B);
  }

  var arrayYc = [];
  for (const zaznam of zaznamyAll) {
    arrayYc.push(zaznam.C);
  }

  var arrayYd = [];
  for (const zaznam of zaznamyAll) {
    arrayYd.push(zaznam.D);
  }

  var arrayYe = [];
  for (const zaznam of zaznamyAll) {
    arrayYe.push(zaznam.E);
  }

  var arrayYfx = [];
  for (const zaznam of zaznamyAll) {
    arrayYfx.push(zaznam.FX);
  }

  var arrayYfn = [];
  for (const zaznam of zaznamyAll) {
    arrayYfn.push(zaznam.FN);
  }

  var trace1 = {
    y: arrayX,
    x: arrayYa,
    name: 'A',
    type: 'bar',
    orientation: 'h',
  };

  var trace2 = {
      y: arrayX,
      x: arrayYb,
      name: 'B',
      type: 'bar',
      orientation: 'h',
  };

  var trace3 = {
      y: arrayX,
      x: arrayYc,
      name: 'C',
      type: 'bar',
      orientation: 'h',
  };

  var trace4 = {
      y: arrayX,
      x: arrayYd,
      name: 'D',
      type: 'bar',
      orientation: 'h',
  };

  var trace5 = {
      y: arrayX,
      x: arrayYe,
      name: 'E',
      type: 'bar',
      orientation: 'h',
  };

  var trace6 = {
      y: arrayX,
      x: arrayYfx,
      name: 'FX',
      type: 'bar',
      orientation: 'h',
  };

  var trace6 = {
    y: arrayX,
    x: arrayYfn,
    name: 'FN',
    type: 'bar',
    orientation: 'h',
  };

  var dataPlotBar = [trace1, trace2, trace3, trace4, trace5, trace6];

  var layout = { 
    barmode: 'group' , 
    font: {
      color: '#fff'
    },
    paper_bgcolor: "rgba(0,0,0,0)",
    plot_bgcolor: "rgba(0,0,0,0)",
    title: 'Barový graf známok študentov', 
    xaxis: 
        {
          title: 'Akademický rok',
        },
    yaxis:
        {
          title: 'Počet študentov',
          tickangle: -50,
        },
    width: 300,
  };

  var config = { responsive: true ,};

  Plotly.newPlot('graphBar', dataPlotBar, layout, config);
  
}

function paintPie(zaznamyAll, rok) {
  for (const zaznam of zaznamyAll){
    if (zaznam.rok === rok) {
      var dataPlotPie = [{
        values: [zaznam.A, zaznam.B, zaznam.C, zaznam.D, zaznam.E, zaznam.FX, zaznam.FN],
        labels: ['A','B','C','D','E','FX','FN'],
        type: 'pie',
        hole: .5
      }];
    }
  }

  config = { 
    responsive: true
  };

  layout = { 
    title: rok,
    font: {
      color: '#fff'
    },
    paper_bgcolor: "rgba(0,0,0,0)",
    plot_bgcolor: "rgba(0,0,0,0)",
  };

  var pieDivName = 'graphPie' + rok.replace(/\s+/g, ''); 
  var pieDiv = document.getElementById(pieDivName);
  if (!pieDiv) {
    pieDiv = document.createElement('div');
    pieDiv.id = pieDivName;
    document.body.appendChild(pieDiv);
  }

  Plotly.newPlot(pieDiv, dataPlotPie, layout, config);
}

function paintCustomGraph(zaznamyAll) {
  var sumSuccess = 0;
  for (const zaznam of zaznamyAll) {
    sumSuccess += parseInt(zaznam.A);
    sumSuccess += parseInt(zaznam.B);
    sumSuccess += parseInt(zaznam.C);
    sumSuccess += parseInt(zaznam.D);
    sumSuccess += parseInt(zaznam.E);
  }

  var sumFail = 0;
  for (const zaznam of zaznamyAll) {
    sumFail += parseInt(zaznam.FX);
    sumFail += parseInt(zaznam.FN);
  }  

  var trace1 = {
    x: ['<A,E>', 'Fx & Fn'],
    y: [sumSuccess, sumFail],
    mode: 'markers',
    marker: {
      size: [sumSuccess/3, sumFail/3],
      color: ['rgb(93, 164, 214)', 'rgb(255, 144, 14)'],
    }
  };
  
  var data = [trace1];
  
  var config = {
    responsive: true,
  };

  var layout = {
    title: 'Marker graf úspešnosti',
    width: 300,
    font: {
      color: '#fff'
    },
    paper_bgcolor: "#rgba(0,0,0,0)",
    plot_bgcolor: "#rgba(0,0,0,0)",
  };
  
  Plotly.newPlot('customGraph', data, layout, config);
}



fetchData();
