console.log("loaded");

let gallery = document.getElementById("gallery");
let filter = document.getElementById("filter");
let images = [];
let slideIndex = 0;
let show = false;

let pauseButton = document.getElementById("pause");
let playButton = document.getElementById("start");
let nextButton = document.getElementById("next");
let previousButton = document.getElementById("prev");

playButton.addEventListener('click', function () {
    show = true;
    clearInterval(slideshowInterval); // Clear previous interval
    slideshowInterval = setInterval(function () {
        slideIndex++;
        if (slideIndex > images.length) {
            slideIndex = 1; // Loop back to the first image
        }
        addImageToModal(slideIndex - 1);
    }, 2000); // Change the interval (in milliseconds) as needed
});

filter.addEventListener('input', filterImages);

async function getImages() {
    try {
        const response = await fetch('./images.json');
        if (!response.ok) {
            throw new Error("Failed to fetch images.");
        }

        const result = await response.json();

        if (result.images && result.images.length > 0) {
            result.images.forEach((img, i) => {
                let thumbnail = createThumbnail(img);
                thumbnail.addEventListener('click', () =>{
                    slideIndex = (i + 1);
                    openModal();
                    show = false;
                });
                gallery.appendChild(thumbnail);
                images.push(img);
            });
        } else {
            console.error("No images found in the response.");
        }
    } catch (error) {
        console.error(error.message);
    }
}

function createThumbnail(img) {
    let thumbnail = document.createElement('img');
    thumbnail.src = img.url;
    thumbnail.alt = img.description;
    thumbnail.classList.add('thumbnail');
    return thumbnail;
}

function normalizeString(str) {
    return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

function filterImages(event) {
    let searchString = normalizeString(event.target.value.toLowerCase());
    let photos = Array.from(gallery.children);

    let filteredImages = photos.filter(photo => {
        return normalizeString(photo.alt.toLowerCase()).includes(searchString);
    });

    photos.forEach(photo => {
        if (filteredImages.includes(photo)) {
            photo.style = "";
        } else {
            photo.style.display = "none";
        }
    });
}

getImages();


// slideshow
var modal = document.getElementById("myModal");
let closeModal = document.getElementById("close");
closeModal.addEventListener('click', function () {
    modal.style.display = "none";
    show = false;
    document.body.style.position = 'static';
});

let slideshowInterval;

function openModal() {
    modal.style.display = "block";
    document.body.style.position = 'fixed';
    addImageToModal(slideIndex - 1);

    // Pause slideshow when the pause button is clicked
    pauseButton.addEventListener('click', function () {
        clearInterval(slideshowInterval);
        show = false;
    });

    // Show the next image when the next button is clicked
    nextButton.addEventListener('click', function () {
        slideIndex++;
        if (slideIndex > images.length) {
            slideIndex = 1; // Loop back to the first image
        }
        addImageToModal(slideIndex - 1);
    });

    // Show the previous image when the previous button is clicked
    previousButton.addEventListener('click', function () {
        slideIndex--;
        if (slideIndex < 1) {
            slideIndex = images.length; // Loop back to the last image
        }
        addImageToModal(slideIndex - 1);
    });

    modal.addEventListener('wheel', function (e) {
        if (modal.style.display === "block") {
            // Adjust the scroll position based on the wheel movement
            modal.scrollTop += e.deltaY;

            // Stop the event propagation to prevent scrolling outside the modal
            e.stopPropagation();
            e.preventDefault();
        }
    });

    closeModal.addEventListener('click', function () {
        clearInterval(slideshowInterval);
        show = false;
        modal.style.display = "none";
    });
    
}

function addImageToModal(index) {
    let modalContent = document.getElementById("modal-content");
    modalContent.innerHTML = "";  
    modalContent.style.marginTop = "300px";
    let modalImageDiv = document.createElement("div");
    modalImageDiv.classList.add("modal-image");

    let modalImage = document.createElement("img");
    modalImage.src = images[index].url;
    modalImage.alt = images[index].description;
    modalImage.style.height = "100vh";
    modalImageDiv.appendChild(modalImage);
    modalContent.appendChild(modalImageDiv);

    // Additional information
    let infoDiv = document.createElement("div");
    infoDiv.classList.add("image-info");
    infoDiv.style.margin = "20px";
    let nameParagraph = document.createElement("h2");
    nameParagraph.textContent = images[index].name;

    let descriptionParagraph = document.createElement("p");
    descriptionParagraph.textContent = images[index].description;

    let timestampParagraph = document.createElement("p");
    timestampParagraph.textContent = images[index].timestamp;

    infoDiv.appendChild(nameParagraph);
    infoDiv.appendChild(descriptionParagraph);
    infoDiv.appendChild(timestampParagraph);

    let mapContainer = document.createElement("div");
    mapContainer.style.height = "300px";  // Set the height of the map as needed

    let map = L.map(mapContainer).setView([images[index].lat, images[index].lng], 10);
    let marker = L.marker([images[index].lat, images[index].lng]).addTo(map);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {

    }).addTo(map);

    infoDiv.appendChild(mapContainer);
    modalContent.appendChild(infoDiv);

    // Invalidate size after a delay
    setTimeout(() => {
        map.invalidateSize();
    }, 100);


    infoDiv.appendChild(mapContainer);
    modalContent.appendChild(infoDiv);
}
