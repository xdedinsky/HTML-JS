var map = L.map('map').setView([48.7, 20], 8);
var routeLayer = L.layerGroup().addTo(map);

L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
}).addTo(map);

var jsonData; 


fetch('./images.json')
    .then(function (response) {
        return response.json();
    })
    .then(function (data) {
        jsonData = data;
        createMarkers();
    })
    .catch(function (error) {
        console.error('Chyba pri načítaní údajov zo súboru:', error);
    });

function createMarkers() {
    var routeL = document.getElementById('routeL');
    routeL.style.display = 'none';
    jsonData.images.forEach(function (image) {
        var marker = L.marker([parseFloat(image.lat), parseFloat(image.lng)])
            .addTo(map);

        marker.on('click', function () {
            displayPhotosOnMap(marker, image);
        });
    });

    var toggleRouteButton = document.getElementById('switch');
    toggleRouteButton.addEventListener('click', function () {
        toggleRouteVisibility();
    });
    map.removeLayer(routeLayer);
}

function displayPhotosOnMap(marker, image) {
    var photosAtLocation = jsonData.images.filter(function (img) {
        return img.lat === image.lat && img.lng === image.lng;
    });

    var popupContent = '<div class="custom-popup">';
    var infoContent = '<div class="custom-popup-info">';
    
    if (photosAtLocation.length === 2) {
        popupContent = '<div class="custom-popup-two">'; // Change class to custom-popup-two
    }

    if (photosAtLocation.length > 1) {
        photosAtLocation.forEach(function (img) {
            popupContent += '<img src="' + img.url + '" alt="' + img.name + '" class="popup-image">';
        });
    }

    if (photosAtLocation.length === 1) {
        photosAtLocation.forEach(function (img) {
            popupContent += '<img src="' + img.url + '" alt="' + img.name + '" class="popup-image-one">';
        });

        infoContent += '<h4>Popis:</h4>';
        photosAtLocation.forEach(function (img) {
            infoContent += '<p>' + img.description + '</p>';
        });
        infoContent += '<h4>GPS:</h4>';
        photosAtLocation.forEach(function (img) {
            infoContent += '<p>' + img.lat + ', ' + img.lng + '</p>';
        });
        infoContent += '<h4>Dátum:</h4>';
        photosAtLocation.forEach(function (img) {
            infoContent += '<p>' + img.timestamp + '</p>';
        });
        popupContent += infoContent;
    }

    popupContent += '</div>';

    var popup = L.popup({ minWidth: 300 })
        .setLatLng(marker.getLatLng())
        .setContent(popupContent)
        .openOn(map);
}


function toggleRouteVisibility() {
    var routeButton = document.getElementById('switch');

    if (routeButton.checked) {
        displayRoute();
        var routeL = document.getElementById('routeL');
        routeL.style.display = 'block';
    } else {
        var routeL = document.getElementById('routeL');
        routeL.style.display = 'none';
        console.log('Skryť trasu');
        map.remove();
        map = L.map('map').setView([48.7, 20], 8);
        L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
        }).addTo(map);
        createMarkers();
    }
}

javascript

Copy


var icons = [
    L.icon({iconUrl: 'red-icon.png', iconSize: [38, 95], iconAnchor: [22, 94], popupAnchor: [-3, -76]}),
    L.icon({iconUrl: 'green-icon.png', iconSize: [38, 95], iconAnchor: [22, 94], popupAnchor: [-3, -76]}),
    L.icon({iconUrl: 'blue-icon.png', iconSize: [38, 95], iconAnchor: [22, 94], popupAnchor: [-3, -76]}),
    L.icon({iconUrl: 'yellow-icon.png', iconSize: [38, 95], iconAnchor: [22, 94], popupAnchor: [-3, -76]}),
    L.icon({iconUrl: 'purple-icon.png', iconSize: [38, 95], iconAnchor: [22, 94], popupAnchor: [-3, -76]})
];

function displayRoute() {
    var routeL = document.getElementById('routeL');
        routeL.style.display = 'none';

    jsonData.images.sort(function(a, b){
        var dateA = new Date(a.timestamp), dateB = new Date(b.timestamp);
        return dateA - dateB;
    });
    
    var waypoints = jsonData.images.map(function (point) {
        return [parseFloat(point.lat), parseFloat(point.lng)];
    });

    if (waypoints.length < 2) {
        console.warn('Nie sú k dispozícii dostatočné údaje pre trasu.');
        return;
    }

    // Check if L.Routing is defined
    if (L.Routing) {
        var routeControl = L.Routing.control({
            waypoints: waypoints,
            routeWhileDragging: true,
            
            formatter: new L.Routing.Formatter({
                units: 'metric',
                roundingSensitivity: 15,
            })
        }).addTo(map);
        
        routeControl.on('routesfound', function (event) {
            var routes = event.routes;
            var totalDistance = 0;

            routes.forEach(function (route) {
                totalDistance += route.summary.totalDistance;
                var routeL = document.getElementById('routeL');
                routeL.innerHTML = 'Dĺžka trasy: ' + (totalDistance / 1000).toFixed(2) + ' km';
            });
            
        });
        
    } else {
        console.error('Leaflet Routing Machine library is not loaded.');
    }
}


