document.addEventListener("DOMContentLoaded", function () {
    const equipmentCheckbox = document.getElementById("equipment");
    const equipmentOptions = document.querySelector(".equipment-options");
    const priceElement = document.getElementById("price");
    const numHoursSelect = document.getElementById("num-hours");
    const birthdateInput = document.getElementById("birthdate");
    const playChoice = document.getElementById('play-choice');
    const competeChoice = document.getElementById('compete-choice');
    const playSection = document.getElementById('play');
    const competitiveSection = document.getElementById('competetive-game-section');
    const competitionCheckboxes = document.querySelectorAll('.competition-checkbox');
    const otherCheckbox = document.getElementById('other-checkbox');
    const otherCompetitionContainer = document.getElementById('other-competition-container');
    const wonOption = document.getElementById('won-option');
    const notWonOption = document.getElementById('not-won-option');
    const competitionOptions = document.getElementById('competition-options');
    const cartType = document.getElementById("cart-equipment-type");
    const equipmentType = document.getElementById("golf-equipment-type");
    const submitButton = document.getElementById("submit");
    const emailInput = document.getElementById('email');
    const buttonName = document.getElementById('name-button'); 
    const nameDisplayDiv = document.getElementById('display-name-div');
    const nameInputB = document.getElementById('display-name-input');
    const priceInput = document.getElementById('price-input');
    nameInputB.value = "Adam Dedinský";

    const toEmail = document.getElementById('to-email');

    buttonName.addEventListener('click', function () {    
        if (nameDisplayDiv.style.display === "none") {
            nameDisplayDiv.style.display = "block";
        } else {
            nameDisplayDiv.style.display = "none";
        }
    });


    submitButton.addEventListener("click", function() {
        const form = document.getElementById("reservation-form");
        form.submit();
      });
    
    calculatePrice();
    
    const nameInput = document.getElementById('name');
    nameInput.addEventListener('input', function () {
        validateName(nameInput);
        updateCharacterCount(nameInput, 'name-character-count');
    });
    nameInput.addEventListener('click', function () {
        validateName(nameInput);
    });
    
    const surnameInput = document.getElementById('surname');
    surnameInput.addEventListener('input', function () {
        validateSurname(surnameInput);
        updateCharacterCount(surnameInput, 'surname-character-count');
    });
    surnameInput.addEventListener('click', function () {
        validateSurname(surnameInput);
    });
    
    emailInput.addEventListener('input', function () {
        updateCharacterCount(emailInput, 'email-character-count');
        validateEmail(emailInput);
    });    
    emailInput.addEventListener('click', function () {
        validateEmailEmpty(emailInput);
    });
    emailInput.addEventListener('blur', function () {
        if(validateEmailEmpty(emailInput)){
            toEmail.value = emailInput.value;
        };
    });
    
    const noteInput = document.getElementById('note');
    noteInput.addEventListener('input', function () {
        updateCharacterCount(noteInput, 'note-character-count');
    });
    
    wonOption.addEventListener('change', showCompetionOptions);
    notWonOption.addEventListener('change', showCompetionOptions);
    
    equipmentCheckbox.addEventListener('change', calculatePrice);
    cartType.addEventListener('change', calculatePrice);
    equipmentType.addEventListener('change', calculatePrice);
    
    const phoneInput = document.getElementById("phone-number");
    const phonePrefix = document.getElementById("phone-prefix");
    phonePrefix.addEventListener('change', function () {
        if (phonePrefix.value === "+421") {phoneInput.maxLength = "9";}
        if (phonePrefix.value === "+420") {phoneInput.maxLength = "10";}
        validatePhone(phoneInput);
        updateCharacterCount(phoneInput, 'phone-character-count');
    });
    phoneInput.addEventListener('input', function () {
        const numericValue = phoneInput.value.replace(/\D/g, '');
        phoneInput.value = numericValue;
        updateCharacterCount(phoneInput, 'phone-character-count');
        validatePhone(phoneInput);
    });
    phoneInput.addEventListener('click', function () {
        validatePhone(phoneInput);
    });
    
    competitionCheckboxes.forEach(function (checkbox) {
        checkbox.addEventListener('change', function () {
            if (otherCheckbox.checked) {
                otherCompetitionContainer.style.display = 'block';
            } else {
                otherCompetitionContainer.style.display = 'none';
            }
        });
    });
    
    otherCheckbox.addEventListener('change', function () {
        if (otherCheckbox.checked) {
            otherCompetitionContainer.style.display = 'block';
        } else {
            otherCompetitionContainer.style.display = 'none';
        }
    });
    
    numHoursSelect.addEventListener("change", function () {
        calculatePrice();
    });
    
    equipmentCheckbox.addEventListener("change", function () {
        if (equipmentCheckbox.checked) {
            equipmentOptions.style.display = "block";
        } else {
            equipmentOptions.style.display = "none";
        }
        calculatePrice();
    });
    
    equipmentOptions.addEventListener("change", function () {
        calculatePrice();
    });
    
    birthdateInput.addEventListener("change", function () {
        validateBirthday(birthdateInput);
        calculateAge(); 
    });
    birthdateInput.addEventListener("click", function () {
        validateBirthday(birthdateInput);
    });
    
    const modalPlay= document.getElementById("view-play");
    const modalCompete = document.getElementById("view-competition");

    playChoice.addEventListener('change', () => {
        calculatePrice();
        if (playChoice.checked) {
            playSection.style.display = 'block';
            competitiveSection.style.display = 'none';
            modalPlay.style.display = "block";
            modalCompete.style.display = "none";
            deleteCompetions();
        }
    });
    
    competeChoice.addEventListener('change', () => {
        calculatePrice();
        if (competeChoice.checked) {
            playSection.style.display = 'none';
            competitiveSection.style.display = 'block';
            modalPlay.style.display = "none";
            modalCompete.style.display = "block";
        }
    });
    
    function calculatePrice() {
        const numHours = numHoursSelect.value;
        const equipmentTypeSelect = document.getElementById("equipment-type");
        const selectedEquipmentType = equipmentTypeSelect.value;
        const equipmentTypeValue = equipmentType.value;
        const cartTypeValue = cartType.value;
        const divEquipment = document.getElementById("div-golf-equipment-type");
        const divCart = document.getElementById("div-cart-equipment-type");
    
        let totalPrice = 0;
    
        if (!equipmentCheckbox.checked) { 
            divEquipment.style.display = "none";
            divCart.style.display = "none";
        }
        if (selectedEquipmentType === "golf-equipments" && equipmentCheckbox.checked) {
            divCart.style.display = "none";
            divEquipment.style.display = "block";
            if (equipmentTypeValue === "only-golf-equipments") {
                totalPrice += 10 * numHoursSelect.value;
            }
            if (equipmentTypeValue === "only-golf-balls") {
                totalPrice += 5 * numHoursSelect.value;
            }
            if (equipmentTypeValue === "golf-equipments-balls") {
                totalPrice += 13 * numHoursSelect.value;
            }
        }
        if (selectedEquipmentType === "golf-cart" && equipmentCheckbox.checked) {
            divEquipment.style.display = "none";
            divCart.style.display = "block";
            if (cartTypeValue === "only-golf-cart-2") {
                totalPrice += 30 * numHoursSelect.value;
            }
            if (cartTypeValue === "only-golf-cart-4") {
                totalPrice += 45 * numHoursSelect.value;
            }
        }
        if (selectedEquipmentType === "golf-cart-equipments" && equipmentCheckbox.checked) {
            divEquipment.style.display = "block";
            divCart.style.display = "block";
            if (equipmentTypeValue === "only-golf-equipments") {
                totalPrice += 10 * numHoursSelect.value;
            }
            if (equipmentTypeValue === "only-golf-balls") {
                totalPrice += 5 * numHoursSelect.value;
            }
            if (equipmentTypeValue === "golf-equipments-balls") {
                totalPrice += 13 * numHoursSelect.value;
            }
            if (cartTypeValue === "only-golf-cart-2") {
                totalPrice += 30 * numHoursSelect.value;
            }
            if (cartTypeValue === "only-golf-cart-4") {
                totalPrice += 45 * numHoursSelect.value;
            }
        }
    
        if (playChoice.checked) {
            if (numHours === "1") {
                totalPrice += 30;
            } else if (numHours === "2") {
                totalPrice += 50;
            } else if (numHours === "3") {
                totalPrice += 80;
            } else if (numHours === "4") {
                totalPrice += 100;
            } else if (numHours === "5") {
                totalPrice += 350;
            }
        }else {
            totalPrice = 20;
        }
    
        priceInput.value = totalPrice;
        priceElement.textContent = totalPrice + " EUR";
    }
    
    function calculateAge() {
        const birthdate = new Date(birthdateInput.value);
        const today = new Date();
        const age = today.getFullYear() - birthdate.getFullYear();
    
        const ageInput = document.getElementById("age");
        ageInput.value = age;
    }
    
    function updateCharacterCount(input, characterCountId) {
        const maxCharacters = input.maxLength;
        const currentCharacters = input.value.length;
        const characterCountElement = document.getElementById(characterCountId);
      
        characterCountElement.textContent = `${currentCharacters}/${maxCharacters}`;
      }
    
    function showCompetionOptions() {
        deleteCompetions();
        if (wonOption.checked) {
            notWonOption.checked = false;
            competitionOptions.style.display = 'block';
        } else {
            notWonOption.checked = true;
            competitionOptions.style.display = 'none';
        }
    }

    function deleteCompetions() {
        const competitionCheckboxes = document.querySelectorAll('.competition-checkbox');
        competitionCheckboxes.forEach(function (checkbox) {
            checkbox.checked = false;
        });
    }
    
    function validateEmail(input) {
        const emailRegex = /^[a-zA-Z0-9._-]{3,}@[a-zA-Z0-9.-]+(?:\.com|\.sk|\.cz)$/;
    
        const email = input.value;
        if (emailRegex.test(email)) {
            document.getElementById("email-error").style.display = "none";
            input.style.border = "1px solid #ccc";
            return true;
        } else {
            document.getElementById("email-error").style.display = "block";
            input.style.border = "1px solid red";
            return false;
        }
    }
    
    function validateEmailEmpty(input) {
        const emailForm = input.value;
        const emailError = document.getElementById('email-error-empty');
    
        if (emailForm.trim() === '') {
            emailError.style.display = 'block';
            input.style.border = '1px solid red';
            return false;
        } else {
            emailError.style.display = 'none';
            input.style.border = '1px solid #ccc';
            return true;
        }
    }
    
    function validatePhone(input) {
        const phonePrefix = document.getElementById("phone-prefix").value;
        const phone = input.value;
        const numericValue = phone.replace(/\D/g, '');
    
        if (phone.length === 0 || phone.length !== input.maxLength) {
            document.getElementById("phone-error").style.display = "block";
            input.style.border = "1px solid red";
            return false;
        }
    
        if (phonePrefix === "+421") {
            var phoneRegex = /^\d{0,9}$/; 
        } else if (phonePrefix === "+420") {
            var phoneRegex = /^\d{0,10}$/; 
        }
    
        if (phoneRegex.test(numericValue)) {
            document.getElementById("phone-error").style.display = "none";
            input.style.border = "1px solid #ccc";
            input.value = numericValue; 
            updateCharacterCount(phoneInput, 'phone-character-count');
            return true;
        } else {
            document.getElementById("phone-error").style.display = "block";
            input.style.border = "1px solid red";
            input.value = numericValue; 
            updateCharacterCount(phoneInput, 'phone-character-count');
            return false;
        }
    }
    
    function validateName(input) {
        const name = input.value;
        const nameError = document.getElementById('name-error');
    
        if (name.trim() === '') {
            nameError.style.display = 'block';
            input.style.border = '1px solid red';
            return false;
        } else {
            nameError.style.display = 'none';
            input.style.border = '1px solid #ccc';
            return true;
        }
    }
    
    function validateSurname(input) {
        const surname = input.value;
        const surnameError = document.getElementById('surname-error');
    
        if (surname.trim() === '') {
            surnameError.style.display = 'block';
            input.style.border = '1px solid red';
            return false;
        } else {
            surnameError.style.display = 'none';
            input.style.border = '1px solid #ccc';
            return true;
        }
    }
    
    function validateBirthday(input) {
        const birthday = input.value;
        const birthdayError = document.getElementById('birthdate-error');
    
        if (birthday === '') {
            birthdayError.style.display = 'block';
            input.style.border = '1px solid red';
            return false;
        } else {
            const currentDate = new Date();
            
            const inputDate = new Date(birthday);
            
            if (inputDate > currentDate) {
                birthdayError.textContent = 'Nesprávny dátum narodenia!';
                birthdayError.style.display = 'block';
                input.style.border = '1px solid red';
                input.value = '';
                return false;
            } else {
                birthdayError.style.display = 'none';
                input.style.border = '1px solid #ccc';
                return true;
            }
        }
    }
    
    function openModal() {
        var modal = document.getElementById("modal");
        modal.style.display = "block";
    
        var nameInput = document.getElementById("name");
        var surnameInput = document.getElementById("surname");
        var emailInput = document.getElementById("email");
        var ageInput = document.getElementById("age");
        var phonePrefix = document.getElementById("phone-prefix");
        var phoneNumberInput = document.getElementById("phone-number");
        var choiceInputs = document.getElementsByName("choice");
        var noteInput = document.getElementById("note"); 
        var manGender = document.getElementById("man");
        var wonChoiceInputs = document.getElementsByName("won-choice");
        var competitionCheckboxes = document.querySelectorAll(".competition-checkbox");
        var otherCompetitionNameInput = document.getElementById("other-competition-name");
        var numHoursInput = document.getElementById("num-hours");
        var equipmentInput = document.getElementById("equipment");
        var equipmentTypeInput = document.getElementById("equipment-type");
        var golfEquipmentTypeInput = document.getElementById("golf-equipment-type");
        var cartEquipmentTypeInput = document.getElementById("cart-equipment-type");

        var namePreview = document.getElementById("name-preview");
        var surnamePreview = document.getElementById("surname-preview");
        var emailPreview = document.getElementById("email-preview");
        var genderPreview = document.getElementById("gender-preview");
        var agePreview = document.getElementById("age-preview");
        var phonePreview = document.getElementById("phone-preview");
        var choicePreview = document.getElementById("choice-preview");
        var notePreview = document.getElementById("note-preview"); 
        var numHoursPreview = document.getElementById("num-hours-preview");
        var equipmentPreview = document.getElementById("equipment-preview");
        var wonChoicePreview = document.getElementById("won-choice-preview");
        var competitionPreview = document.getElementById("competition-preview");
        var otherCompetitionPreview = document.getElementById("other-competition-preview");

        namePreview.innerHTML = "<h2>Meno: </h2>" + nameInput.value;
        surnamePreview.innerHTML = "<h2>Priezvisko: </h2>" + surnameInput.value;
        emailPreview.innerHTML = "<h2>Email: </h2>" + emailInput.value;
        
        var selectedCompetitions = [];
        var selectedWonChoice = "";

        if (manGender.checked){
            genderPreview.innerHTML = "<h2>Pohlavie: </h2>Muž";
        } else {
            genderPreview.innerHTML = "<h2>Pohlavie: </h2>Žena";
        }

        agePreview.innerHTML = "<h2>Vek: </h2>" + ageInput.value;
        phonePreview.innerHTML = "<h2>Tel. číslo: </h2>" + phonePrefix.value + " " + phoneNumberInput.value;
        
        var selectedChoice = "";
        for (var i = 0; i < choiceInputs.length; i++) {
            if (choiceInputs[i].checked) {
                selectedChoice = choiceInputs[i].value;
                break;
            }
        }
        if (selectedChoice === "play"){
            choicePreview.innerHTML = "<h2>Záujem: </h2>Hrať";
        } else {
            choicePreview.innerHTML = "<h2>Záujem: </h2>Súťažiť";
        }

        

        if (selectedChoice === "play") {  
            wonChoiceInputs.name = "";
            otherCompetitionNameInput.name = "";
            wonChoiceInputs.name = "";
            numHoursPreview.innerHTML = "<h2>Počet hodín: </h2>" + numHoursInput.options[numHoursInput.selectedIndex].text;

            if (equipmentInput.checked) {
                if (equipmentTypeInput.value === "golf-equipments") {
                    equipmentPreview.innerHTML = "<h2>Doplnky: </h2>" + golfEquipmentTypeInput.options[golfEquipmentTypeInput.selectedIndex].text;
                } else if (equipmentTypeInput.value === "golf-cart") {
                    equipmentPreview.innerHTML = "<h2>Doplnky: </h2>" + cartEquipmentTypeInput.options[cartEquipmentTypeInput.selectedIndex].text;
                } else {
                    equipmentPreview.innerHTML = "<h2>Doplnky: </h2>" + golfEquipmentTypeInput.options[golfEquipmentTypeInput.selectedIndex].text + ", " + cartEquipmentTypeInput.options[cartEquipmentTypeInput.selectedIndex].text;
                }
            } else {
                equipmentPreview.innerHTML = "<h2>Bez doplnkov</h2>";
            }

            
        } else if (selectedChoice === "competitive") {
            numHoursInput.name = "";
            equipmentInput.name = "";
            equipmentTypeInput.name = "";
            golfEquipmentTypeInput.name = "";
            cartEquipmentTypeInput.name = "";
            for (var i = 0; i < wonChoiceInputs.length; i++) {
                if (wonChoiceInputs[i].checked) {
                    selectedWonChoice = wonChoiceInputs[i].value;
                    break;
                }
            }
            wonChoicePreview.innerHTML = "<h2>Vyhral si už súťaž? </h2>" + (selectedWonChoice === "won" ? "Áno" : "Nie");

            var selectedCompetitions = [];
            competitionCheckboxes.forEach(function(checkbox) {
                if (checkbox.checked) {
                    selectedCompetitions.push(checkbox.value);
                }
            });
            competitionPreview.innerHTML = "<h2>Vybrané súťaže: </h2>" + selectedCompetitions.join(", ");
            
            if (selectedCompetitions.includes("Other")) {
                otherCompetitionPreview.innerHTML = "<h2>Iná súťaž: </h2>" + otherCompetitionNameInput.value;
            } else {
                otherCompetitionPreview.textContent = "";
            }}
        
            notePreview.innerHTML = "<h2>Poznámka: </h2>" + noteInput.value;

            var totalPricePreview = document.getElementById("price-preview");
            totalPricePreview.innerHTML = "<h1>Výsledná suma: " + priceElement.textContent + "</h1>";
    };
    
    function closeModal() {
        var modal = document.getElementById("modal");
        modal.style.display = "none";
    }
    
    var checkButton = document.querySelector("#buttonCheck");
    checkButton.addEventListener("click", function(event) {
        event.preventDefault();

        var isValid = true;

        if (!validateName(nameInput)) {
            isValid = false;
          }
      
          if (!validateSurname(surnameInput)) {
            isValid = false;
          }
      
          if (!validateEmail(emailInput)) {
            isValid = false;
          }
      
          if (!validateEmailEmpty(emailInput)) {
            isValid = false;
          }
      
          if (!validatePhone(phoneInput)) {
            isValid = false;
          }
      
          if (!validateBirthday(birthdateInput)) {
            isValid = false;
          }
      
          if (isValid) {
            openModal();
          }
        });

    var closeButton = document.querySelector(".close");
    closeButton.addEventListener("click", function() {
        closeModal(); 
    });
    
});
  